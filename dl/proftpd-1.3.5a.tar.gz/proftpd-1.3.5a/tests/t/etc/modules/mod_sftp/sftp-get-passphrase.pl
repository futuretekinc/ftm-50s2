#!/usr/bin/env perl

use strict;

my $passphrase = "password";

print STDOUT "$passphrase\n";
exit 0;
