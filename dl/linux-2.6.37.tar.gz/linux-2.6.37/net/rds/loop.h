#ifndef _RDS_LOOP_H
#define _RDS_LOOP_H

/* loop.c */
extern struct rds_transport rds_loop_transport;

void rds_loop_exit(void);

#endif
