#include <stdio.h>

main()
{
printf("Content-type: text/html\n\n"); /* 1 */

printf( "<HTML>\n<HEAD><TITLE>Sample 1 CGI</TITLE></HEAD>\n<BODY><H1>This is My First CGI Program!!</H1>\n</BODY>\n</HTML>\n"); /* 2 */ }

