#/bin/ash
cat /proc/cmdline | awk -f dev_info.awk

